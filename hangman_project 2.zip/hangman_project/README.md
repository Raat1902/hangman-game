# Hangman Game (C++)

A simple console-based Hangman game written in C++. 

## Features

- Random word selection from a word bank
- Tracks correct and wrong guesses
- Displays remaining lives
- Console-based user interface
- Beginner-friendly project

## How to Compile and Run

```bash
g++ -o hangman hangman.cpp
./hangman
```

## Project Purpose

- Loops
- Conditionals
- Functions
- Vectors
- Strings
- User input handling

## Future Improvements

- Load word bank from external file
- Difficulty levels
- ASCII art
- Replay option
- Score tracking
