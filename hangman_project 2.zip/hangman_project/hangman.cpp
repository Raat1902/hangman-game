#include <iostream>
#include <vector>
#include <string>
#include <algorithm> 
#include <ctime>
#include <cstdlib>

using namespace std;

void displayWord(const string& word, const vector<char>& correctGuesses) {
    for (char c : word) {
        if (find(correctGuesses.begin(), correctGuesses.end(), c) != correctGuesses.end()) {
            cout << c << " ";
        } else {
            cout << "_ ";
        }
    }
    cout << endl;
}


bool isWordGuessed(const string& word, const vector<char>& correctGuesses) {
    for (char c : word) {
        if (find(correctGuesses.begin(), correctGuesses.end(), c) == correctGuesses.end()) {
            return false;
        }
    }
    return true;
}

int main() {
    vector<string> wordBank = {
        "APPLE", "BANANA", "ORANGE", "PEACH", "GRAPE", "LEMON", "MANGO", "CHERRY", "KIWI"
    };

    srand(static_cast<unsigned int>(time(0)));

    
    string secretWord = wordBank[rand() % wordBank.size()];

    
    int lives = 6;
    vector<char> correctGuesses;
    vector<char> wrongGuesses;

    cout << "====== HANGMAN ======" << endl;
    cout << "Guess the word! You have " << lives << " lives." << endl;


    while (lives > 0 && !isWordGuessed(secretWord, correctGuesses)) {
        cout << "\nWord: ";
        displayWord(secretWord, correctGuesses);

        cout << "Wrong guesses: ";
        for (char c : wrongGuesses) {
            cout << c << " ";
        }
        cout << endl;

        cout << "Lives remaining: " << lives << endl;

        cout << "Enter a letter: ";
        char guess;
        cin >> guess;

       
        guess = toupper(guess);

      
        if (find(correctGuesses.begin(), correctGuesses.end(), guess) != correctGuesses.end() ||
            find(wrongGuesses.begin(), wrongGuesses.end(), guess) != wrongGuesses.end()) {
            cout << "You already guessed that letter! Try again." << endl;
            continue;
        }

 
        if (secretWord.find(guess) != string::npos) {
            cout << "Good guess!" << endl;
            correctGuesses.push_back(guess);
        } else {
            cout << "Wrong guess!" << endl;
            wrongGuesses.push_back(guess);
            lives--;
        }
    }

  
    if (isWordGuessed(secretWord, correctGuesses)) {
        cout << "\nCongratulations! You guessed the word: " << secretWord << endl;
    } else {
        cout << "\nGame over! The word was: " << secretWord << endl;
    }

    return 0;
}
